<h1 align="center">assalamu'alaikum <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>I'm Kz.tutorial </h1>
<p align="center">
  <img src="https://b.top4top.io/p_2310io7yo0.jpg" />
</p>


- 👼 My name is Juliopangkey
- 🍼 I am 19 years old 
- 🔭 I am not programmer

<h1 align="center"> Connect with me
<p align="center">
  <a href="https://api.whatsapp.com/send/?phone=628992176733&text=Assalamualaikum+Stah+Bolehkah+Kita+Berteman+?"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  <a href="https://t.me/KZtutorial"><img src="https://img.shields.io/badge/telegram-25D366?style=for-the-badge&logo=telegram&logoColor=white" />
  <a href="https://github.com/KZtutorial"><img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github" /> 
  <a href="https://youtube.com/channel/UCRaVHUXQGVAH7Gof7kixIoQ"><img src="https://img.shields.io/youtube/channel/subscribers/UCMnOhcDe_-8yE9jobx-JenA?style=social" /> <br>
</p>


![Profile Dilihat](https://komarev.com/ghpvc/?username=pinomodz&color=blue&style=flat-square&label=Profile+Dilihat)
### Stats:

<p align="center"><a href="https://github.com/PinoRecode"><img src="https://github-readme-stats.vercel.app/api?username=PinoRecode&show_icons=true&theme=radical"></a></p>
<p align="center"><a href="https://github.com/PinoRecode"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=PinoRecode&theme=radical&layout=compact"></a></p> 

## Repo Stats
![github card](https://github-readme-stats.vercel.app/api/pin/?username=PinoRecode&repo=ABOUT&theme=nightowl)
![github card](https://github-readme-stats.vercel.app/api/pin/?username=PinoRecode&repo=home-termux-pinomod&theme=nightowl)
![github card](https://github-readme-stats.vercel.app/api/pin/?username=PinoRecode&repo=Bot-Wa&theme=nightowl)
![github card](https://github-readme-stats.vercel.app/api/pin/?username=PinoRecode&repo=self&theme=nightowl)


<p>
    <img src="https://img.shields.io/badge/OS-Linux-blue?&logo=Linux" />
    <img src="https://img.shields.io/badge/OS-Windows-blue?&logo=Windows" />
    <img src="https://img.shields.io/badge/IDE-Xcode-blue?&logo=xcode" />
    <img src="https://img.shields.io/badge/Text%20Editor-Visual%20Studio%20Code-blue?&logo=visual%20studio%20code&logoColor=blue" />
    <img src="https://img.shields.io/badge/Sublime%20Text-gray?&logo=Sublime-Text" />
</p>
<details>
    <summary>&#127942 <b>GitHub Awards</b></summary><br/>

![Github Trophy](https://github-profile-trophy.vercel.app/?username=phaticusthiccy)

</details>

<details>
    <summary>&#127942 <b>GitHub Activity</b></summary><br/>

![Metrics](https://metrics.lecoq.io/PinoRecode?template=classic&repositories.forks=true&languages=1&languages.colors=github&languages.threshold=0%25&config.timezone=Asia%2FSemarang)

</details>

<p>

>
>
>
</div>
<p align="center">
  <a href="https://github.com/KZtutorial/"><img title="Author" src="https://img.shields.io/badge/Author-Kz.tutorial-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://wa.me/628992176733"> CHAT DEVELOPER </a>
</h4>
</p>

```bash

> Cara Setting Tampilan Termux Menjadi Lebih Keren:v

```
## PREVIEW
<p align="center">
  <img src="https://k.top4top.io/p_231058c5h0.png" />
</p>
  
## CMD INSTALL 
```bash 
> $ apt update && apt upgrade
> $ pkg install figlet
> $ pkg install lolcat
> $ pkg install python2
> $ pkg install bash
> $ pkg install python
> $ pkg install nano

> jika bahan-bahan di atas sudah terinstall kalian ketikan eksekusi.
> caranya adalah:

> $ pkg install git
> $ git clone https://github.com/kZtotorial/TAMPILAN-TERMUX
> $ cd TAMPILAN-TERMUX
> $ ls
> $ python tampilan-stayling.py

```
